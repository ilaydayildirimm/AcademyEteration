package stepdefs;

import base.Driver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import pages.HomePage;


import java.time.Duration;

public class MyStepdefs {

    HomePage homePage = new HomePage();
    private WebDriver driver;
    @Given("User navigates to home page")
    public void userNavigatesToHomePage() {
        driver = Driver.getDriver();
        driver.manage().window().maximize();
        driver.get("https://academy.eteration.com/");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
    }

    @When("User clicks instructors button on Home Page")
    public void userClicksInstructorsButtononHomePage() {
        homePage.clickInstructorsButton();
    }

    @And("User check instructor list is not empty")
    public void userCheckInstructorListisNotEmpty() {
        homePage.checkInstructorList();
    }

    @Then("User checks if the number of list is 8")
    public void userChecksIftheNumberOfList() {
        homePage.checkInstructorCountList();
    }
}

