package pages;

import base.BaseTest;
import base.Driver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class HomePage extends BaseTest {
    WebDriver driver;
    private String InstructorsButtonXpath = "//*[@id=\"nav\"]/ul/li[2]/a";
    public HomePage()
    {
        driver = Driver.getDriver();
        PageFactory.initElements(driver,this);
    }

    public void clickInstructorsButton() {
        click(driver.findElement(By.xpath(InstructorsButtonXpath)));

    }

    public void checkInstructorList() {
        WebElement instructorList = driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div/div[2]"));

        // Eğer liste boşsa, ilgili mesajı yazdır
        if (instructorList.getText().trim().isEmpty()) {
            System.out.println("Eğitmen listesi şu an boş.");
        } else {
            System.out.println("Eğitmen listesi mevcuttur.");
        }
    }

    public void checkInstructorCountList() {
        try {
            // Eğitmen öğelerini liste olarak bul
            List<WebElement> instructors = driver.findElements(By.cssSelector("div.instructor-item"));

            // Eğitmen sayısını yazdır
            System.out.println("\"Eğitmen listesinde 8 eğitmen yok. Şu anki eğitmen sayısı " + instructors.size());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Tarayıcıyı kapat
            driver.quit();
        }

    }
}


